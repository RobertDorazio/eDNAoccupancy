## ----setup, include=FALSE------------------------------------------------
library(knitr)
opts_chunk$set(fig.path='figure/latex-', cache.path='cache/latex-', comment=NA, prompt=TRUE)
knit_theme$set('biogoo')

## ----showArguments,  eval=FALSE------------------------------------------
#  occModel(formulaSite, formulaSiteAndSample, formulaReplicate,
#     detectionMats, siteData = NULL, siteAndSampleData = NULL,
#     niter, niterInterval, siteColName="site", sampleColName="sample")

## ----loadFungalPathogenData----------------------------------------------
library(eDNAoccupancy)
data(fungusDetectionData)
data(fungusSurveyData)

## ----printFungusDetectionData--------------------------------------------
head(fungusDetectionData)

## ----printFungusSurveyData-----------------------------------------------
head(fungusSurveyData)

## ----computeFungusDetections---------------------------------------------
fungusDetections = occData(fungusDetectionData, siteColName = 'site',
                           sampleColName = 'sample')
#
## number of detections per sample
head(fungusDetections$y)
## number of PCR replicates per sample
head(fungusDetections$K)

## ----fitNoCovModelToFungusData-------------------------------------------
set.seed(0157)
fit = occModel(detectionMats=fungusDetections, niter=11000,
               niterInterval=5000)
posteriorSummary(fit, burnin=1000, mcError=TRUE)

## ----fitFrogCovModelToFungusData-----------------------------------------
## Center and scale numeric-valued covariate measurements
fungusSurveyData.sc = scaleData(fungusSurveyData)

set.seed(0157)
fit = occModel(formulaSite          = ~ 1,
               formulaSiteAndSample = ~ frogs,
               formulaReplicate     = ~ 1,
               detectionMats        = fungusDetections,
               siteData             = fungusSurveyData.sc,
               niter                = 6000,
               niterInterval        = 2000,
               siteColName = 'site'
               )
posteriorSummary(fit, burnin=1000, mcError=TRUE)

## ----TracePlotFungusAnalysis, fig.lp="fig:", out.width="60%", fig.align="center", fig.cap="Trace plots of parameters of model fitted to fungal pathogen data."----
plotTrace(fit, c('beta.(Intercept)', 'alpha.(Intercept)', 'alpha.frogs',
            'delta.(Intercept)'),  burnin=1000)

## ----ACFPlotFungusAnalysis, fig.lp="fig:", out.width="60%", fig.align="center", fig.cap="Autocorrelation plots of parameters of model fitted to fungal pathogen data."----
plotACF(fit, c('beta.(Intercept)', 'alpha.(Intercept)', 'alpha.frogs',
            'delta.(Intercept)'),  burnin=1000)

## ----updateFrogCovModelToFungusData--------------------------------------
fit = updateOccModel(fit, niter=5000, niterInterval=2000)
posteriorSummary(fit, burnin=1000,  mcError=TRUE)

## ----estimateDerivedParamsForFungusAnalysis------------------------------
psi = posteriorSummaryOfSiteOccupancy(fit, burnin=1000)
theta = posteriorSummaryOfSampleOccupancy(fit, burnin=1000)
p = posteriorSummaryOfDetection(fit, burnin=1000)
#
## output estimates of posterior medians
cbind(psi=psi$median, theta=theta$median[,1], p=p$median[,1])

## ----FungusOccEstimates, fig.lp="fig:", out.width="60%", fig.align="center", fig.cap="Estimated probabilities of occurrence of Bd eDNA in samples collected from ponds with different densities of frogs.  Symbols are estimates of posterior medians with 95 percent credible intervals."----
frogs = fungusSurveyData[, 'frogs']
plot(frogs, theta$median[,1], ylim=c(0,1), xlim=c(0,0.8), cex=2)
segments(frogs, theta$lower[,1], frogs, theta$upper[,1], lwd=2)

## ----modelSelectionForFungusAnalysis-------------------------------------
posteriorPredictiveLoss(fit, burnin=1000)
WAIC(fit, burnin=1000)

## ----loadGobyData--------------------------------------------------------
library(eDNAoccupancy)
data(gobyDetectionData)
data(gobySurveyData)

## ----printGobyDetectionData----------------------------------------------
head(gobyDetectionData)

## ----printGobySurveyData-------------------------------------------------
head(gobySurveyData)

## ----fitModelToGobyData--------------------------------------------------
### Compute occupancy data matrices
gobyDetections = occData(gobyDetectionData, siteColName = 'site',
                         sampleColName = 'sample')
#
## Center and scale numeric-valued covariate measurements
gobySurveyData.sc = scaleData(gobySurveyData)
#
set.seed(0157)
fit = occModel(formulaSite          = ~ veg,
               formulaSiteAndSample = ~ sal+twg,
               formulaReplicate     = ~ sal+fish+turb,
               detectionMats        = gobyDetections,
               siteData             = gobySurveyData.sc,
               niter                = 11000,
               niterInterval        = 2000,
               siteColName = 'site'
               )
posteriorSummary(fit, burnin=1000, mcError=TRUE)

## ----estimateDerivedParamsForGobyAnalysis--------------------------------
psi = posteriorSummaryOfSiteOccupancy(fit, burnin=1000)
theta = posteriorSummaryOfSampleOccupancy(fit, burnin=1000)
p = posteriorSummaryOfDetection(fit, burnin=1000)
#
## output estimates of posterior medians
cbind(psi=psi$median, theta=theta$median[,1], p=p$median[,1])

## ----GobyOccEstimates, fig.lp="fig:", out.width="60%", fig.align="center", fig.cap="Estimated probabilities of occurrence of goby eDNA in samples of different salinities.  Symbols are estimates of posterior medians with 95 percent credible intervals."----
salinity = gobySurveyData[, 'sal']
plot(salinity, theta$median[,1], ylim=c(0.4,1), cex=2)
segments(salinity, theta$lower[,1], salinity, theta$upper[,1], lwd=2)

## ----GobyDetectionEstimates, fig.lp="fig:", out.width="100%", fig.align="center", fig.cap="Estimated probabilities of detection of goby eDNA in PCR replicates.  Symbols are estimates of posterior medians with 95 percent credible intervals."----
ylimits = c(0.2,1)
par(mfrow=c(1,3))
salinity = gobySurveyData[, 'sal']
plot(salinity, p$median[,1], ylim=ylimits, cex=2, main='sal')
segments(salinity, p$lower[,1], salinity, p$upper[,1], lwd=2)
fish = gobySurveyData[, 'fish']
plot(fish, p$median[,1], ylim=ylimits, cex=2, main='fish')
segments(fish, p$lower[,1], fish, p$upper[,1], lwd=2)
turb = gobySurveyData[, 'turb']
plot(turb, p$median[,1], ylim=ylimits, cex=2, main='turb')
segments(turb, p$lower[,1], turb, p$upper[,1], lwd=2)

